<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'sqlite:@app/db.sqlite',
    'charset' => 'utf8',
];
